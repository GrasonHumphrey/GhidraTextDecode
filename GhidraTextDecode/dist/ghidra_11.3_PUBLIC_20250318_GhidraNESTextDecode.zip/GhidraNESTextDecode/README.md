# GhidraNESTextDecode
